/* -----------------------------------------------------------------------------------------------------------
   C39006: Assignment 6 ​ (​ GROUP ASSIGNMENT​ )
   Assignment 6 - File Transfer using Stream Socket
   Animesh Jain  18CS10004
   Abhinav Bohra 18CS30049
   File_Client.c
-------------------------------------------------------------------------------------------------------------*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<errno.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include <netdb.h> 
#include<netinet/in.h>
#include <stdbool.h> 

#define MAX 80 
#define PORT 8080 
#define SA struct sockaddr 
//------------------------------------------------------------------------------------------------------------------
//Function Prototyping
bool isDelimeter(char ch);
int countWords(char* buff, int buffBytes, int *prev);

//------------------------------------------------------------------------------------------------------------------

int main() 
{ 
	int sockfd, connfd; 	
	struct sockaddr_in servaddr, cli; 

	// Step 1 : Socket Creation and Verification 
	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd < 0) { 
		printf("\x1b[31mSOCKET CREATION FAILED.....EXITING\x1b[0m\n"); 
		exit(EXIT_FAILURE); 
	} 
	else printf("\x1b[32mSOCKET CREATED SUCCESSFULLY\x1b[0m\n"); 
	bzero(&servaddr, sizeof(servaddr)); 

	// Filing Address Informaiton 
    	servaddr.sin_family = AF_INET;           //Domain - IPV4
   	servaddr.sin_addr.s_addr = INADDR_ANY;   //Localhost
    	servaddr.sin_port = htons(PORT);         //PORT - 8080


	// Step 2: Client establishes a connection to the server using the ​ connect()​ call. 
	if (connfd = connect(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0) { 
		printf("\x1b[31mFAILED TO CONNNECT WITH SERVER....TRY AGAIN\x1b[0m\n"); 
		exit(EXIT_FAILURE); 
	} 
	else printf("\x1b[32mCONNECTED TO SERVER\x1b[0m\n"); 

	
	//Step 3 : The client reads the filename from the user (console input) and sends the file name to the server.

	char filename[MAX];	
	printf("\x1b[36mENTER FILENAME:\x1b[0m"); 
	scanf("%s",filename);
    	sendto(sockfd, (const char *)filename, strlen(filename), MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr)); 


	//Step 4 :
	char buffer[MAX];
	int fd, flag = 0; // flag =1 File reading is ongoing 
	int numWords = 0, numBytes = 0;
	int prev = 1; // prev=1 means last character of previous buffer is a non-delimiter char (See func countWords for more details)
		
	while(1){
		
		char *outputFile = filename;
		//The recv() function shall return the length of the message in bytes written to the buffer pointed to by the buffer argument
		int buffBytes = recv(sockfd, (char *)buffer, sizeof(buffer), 0);
		
		if(buffer[0]=='\0'){ //Handling Empty File
			memset(buffer,0,sizeof(buffer));
			buffBytes=0;
			flag=1;
			fd = open(outputFile, O_WRONLY | O_TRUNC | O_CREAT, S_IRWXU);
			write(fd,"",1); // Write the buffer received to the file
		}

		// Exit if connection closed by server when file is not present
		if( (buffBytes < 0 && errno == ECONNRESET && flag == 0) || (buffBytes == 0 && flag == 0) )
		{
			printf("\x1b[31mERR 01: File Not Found\x1b[0m\n"); 	
			close(sockfd);      // Close the socket
			exit(EXIT_FAILURE); // Exit 
		}

		if( flag == 0) fd = open(outputFile, O_WRONLY | O_TRUNC | O_CREAT, S_IRWXU); // Opening new file to write the data
		
		// Check when the file is done being transferred
		if( (buffBytes < 0 && errno == ECONNRESET && flag == 1) || (buffBytes == 0 && flag == 1) )
		{
			//Prev = 1 means a word was shared between 2 consectuive buffers, so no need to increase word count
			//Prev = 0 means there were 2 seperate words at the boundaries of 2 consectuive buffers, thus increase count by one

			if(prev == 0) numWords ++;
			
			printf("\x1b[34mFILE RECEIVED SUCCESSFULLY.\x1b[0m\n");
			printf("\x1b[34mFILE CONTENTS STORED IN %s.\x1b[0m\n",outputFile); 
			printf("\x1b[33mSize of file = %d bytes, no. of words = %d.\x1b[0m\n", numBytes, numWords);
			printf("\x1b[32mCONNECTION CLOSED BY SERVER\x1b[0m\n\n"); 
			close(sockfd);
			close(fd);
			exit(EXIT_SUCCESS);	
		}

		write(fd, (const void *)buffer, (size_t)buffBytes); // Write the buffer received to the file	
		numBytes += buffBytes; 			            // Add size of current buffer to total size
		numWords += countWords(buffer, buffBytes, &prev);   // Count words in buffer
		flag = 1; // Mark file as present.
	}
	
	close(sockfd);
	return 0;
	
} 
//------------------------------------------------------------------------------------------------------------------
//User Defined Functions

bool isDelimeter(char ch)
{
	if(ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r' || ch == ';' || ch == ':' || ch == ',' || ch == '.' || ch == EOF ) return true;
	return false;
}

int countWords(char* buff, int buffBytes, int *prev)
{
	/*
	Argument : buff -> Pointer to charater array storing contents of buffer
		   buffBytes -> Length of the message written to the buffer pointed to by the buffer argument
		   prev -> When equal to 1 means last character of previous buffer is a non-delimiter char, else otherwise
	LOGIC : Total Number of words in entire file = Sum of words in each buffer
	However, we need to check start and end each buffer, to see if a word is being shared by two consecutive buffers
	
	*/
	int i = 0, words = 0;

	if ( isDelimeter(buff[0]) == false ) *prev = 0;            	  // If first character of current buffer is non-delimiter character, then update prev=0
	
	while(i < buffBytes){
		while( i < buffBytes && isDelimeter(buff[i]) == false ) i++;   // Go to the first delimiting character
		if( i < buffBytes && *prev == 0) words ++;		  // Increase the word count by 1
		*prev = 0; 						  // Reinitialise prev marker
		while( i < buffBytes && isDelimeter(buff[i]) == true ) i++; 	  // Go to the first non-delemiting char, this handles multiple consecutiveoccurences of delimeter
	}

	if ( isDelimeter(buff[i-1]) == true ) *prev = 1; 			  // Mark the end as delimiter
	return words; // Return words
}
//------------------------------------------------------------------------------------------------------------------

