/* --------------------------------------------------------------------------------------------------------------
   C39006: Assignment 6 ​ (​ GROUP ASSIGNMENT​ )
   Assignment 6 - File Transfer using Stream Socket
   Animesh Jain  18CS10004
   Abhinav Bohra 18CS30049
   File_Server.c
-----------------------------------------------------------------------------------------------------------------*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<errno.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include <netdb.h> 
#include<netinet/in.h>

#define MAX 80                //Buffer Size kept < 100
#define PORT 8080 
#define SA struct sockaddr 

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
int main() 
{ 	

	int sockfd, len; 
 	struct sockaddr_in servaddr, cli; 
  
	// Step 1 : Socket Creation and Verification 
	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd < 0) { 
		printf("\x1b[31mSOCKET CREATION FAILED.....EXITING\x1b[0m\n"); 
		exit(EXIT_FAILURE); 
	} 
	else printf("\x1b[32mSOCKET CREATED SUCCESSFULLY\x1b[0m\n"); 
	bzero(&servaddr, sizeof(servaddr)); 

	// Filing Address Informaiton 
    	servaddr.sin_family = AF_INET;           //Domain - IPV4
   	servaddr.sin_addr.s_addr = INADDR_ANY;   //Localhost
    	servaddr.sin_port = htons(PORT);         //PORT - 8080


	// Step 2: Binding newly created socket to given IP and verification 
	if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) { 
		printf("\x1b[31mSOCKET BINDING FAILED.....EXITING\x1b[0m\n"); 
		exit(EXIT_FAILURE); 
	} 
    	else printf("\x1b[32mSOCKET SUCCESSFULLY BINDED\x1b[0m\n"); 
	
	// Now server is ready to listen and verification 
	if ((listen(sockfd, 5)) != 0) { 
		printf("\x1b[31mAHHH.....CANT LISTEN YOU :(\x1b[0m\n"); 
		exit(EXIT_FAILURE); 
	} 
	else  printf("\x1b[44mSERVER IS UP!........LISTENING\x1b[0m\n\n"); 
	len = sizeof(cli);  
		  
	while(1){

		/*The server process keeps on waiting for the next client connection. 
		The server process needs to be closed by sending an interrupt (using CTRL + C) from the console.*/
 		
		// Step 3: Accept the data packet from client and verification 
    		int connfd = accept(sockfd, (SA*)&cli, &len); 
    		if (connfd < 0) { 
    	   		printf("\x1b[31mSERVER ACCEPT FAILED\x1b[0m\n"); 	
            		exit(EXIT_FAILURE); 
	   	} 
	    	else printf("\x1b[32mSERVER ACCEPTED CLIENT CONNECTION\x1b[0m\n"); 
	      	printf("\x1b[34mESTABLISHED CONNECTION WITH %s:%d\x1b[0m\n", inet_ntoa(cli.sin_addr), ntohs(cli.sin_port)); // Print the IP of the established connection
		printf("\x1b[34mWAITING FOR FILE REQUEST\x1b[0m\n");

		// Step 4: Receive the filename
		char filename[MAX]; 			
		int n = recv(connfd, (char *)filename, sizeof(filename), 0);		
		filename[n] = '\0';
		printf("\x1b[33mSEARCHING FILE: %s\x1b[0m\n", filename); //The server looks for the file in the local directory, 		
		
		int fd = open(filename, O_RDONLY); // Opening file in READ ONLY MODE

		// Step 5: Check for the file presence
		if(fd < 0)
		{
			printf("\x1b[31mFILE NOT FOUND. CLOSING CONNECTION\x1b[0m\n\n");
			close(connfd);  //Close the connection
			close(fd);      //Close the file descriptor
			continue;	//Start next iteration
		}

		else{
		/* Step 6: If the file is present, the server reads the contents of the file and sends the file 
		   in small chunks using multiple send() calls until the entire file is transferred */

			char sendFile[MAX];	
			int count=0;
			while(1)
			{
				int buffBytes = read(fd, (void *)sendFile, MAX); // Read from the file descriptor
				
				//Handling Empty File
				if(count==0 && buffBytes==0) {
					send(connfd, (char *)"", sizeof(""), 0);
				} 
				count++;			
				// read() returns: How many bytes were actually read & return 0 on reaching end of file & -1 on error 
				if(buffBytes == 0) // EOF reached 
				{
					printf("\x1b[32mFILE SENT SUCCESSFULLY. CLOSING CONNECTION\x1b[0m\n\n"); 
					close(connfd);  //Close the connection
					close(fd);      //Close the file descriptor
					break;	
				}
				
				send(connfd, (char *)sendFile, buffBytes, 0); // send the message in the buffer to the client
			}
		} 
	}	
	close(sockfd);	
	return 0;
} 

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
