/* -----------------------------------------------------------------------------------------------------------
   C39006: Networks Laboratory​ (​ GROUP ASSIGNMENT​ )
   Assignment 7 - File Transfer in Blocks
   Animesh Jain  18CS10004
   Abhinav Bohra 18CS30049
   File_Client.c
-------------------------------------------------------------------------------------------------------------*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<errno.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<netdb.h> 
#include<netinet/in.h>
#include<stdbool.h> 

#define B 20 
#define MAXSIZE 1000 
#define PORT 8080 
#define SA struct sockaddr 
//------------------------------------------------------------------------------------------------------------------

int main() 
{ 
	int sockfd, connfd,FSIZE; 
	char buffer[MAXSIZE];
	struct sockaddr_in servaddr, cli; 

	// Step 0 : Socket Creation and Verification 
	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd < 0) { 
		printf("\x1b[31mSOCKET CREATION FAILED.....EXITING\x1b[0m\n"); 
		exit(EXIT_FAILURE); 
	} 
	else printf("\x1b[32m\nSOCKET CREATED SUCCESSFULLY\x1b[0m\n"); 
	bzero(&servaddr, sizeof(servaddr)); 
	// Filing Address Informaiton 
    	servaddr.sin_family = AF_INET;           //Domain - IPV4
   	servaddr.sin_addr.s_addr = INADDR_ANY;   //Localhost
    	servaddr.sin_port = htons(PORT);         //PORT - 8080
	int enable = 1;
	setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(enable));

	// Step 1: Client establishes a connection to the server using the ​ connect()​ call. 
	if (connfd = connect(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0) { 
		printf("\x1b[31mFAILED TO CONNNECT WITH SERVER....TRY AGAIN\x1b[0m\n"); 
		exit(EXIT_FAILURE); 
	} 
	else printf("\x1b[32mCONNECTED TO SERVER\x1b[0m\n"); 

	
	//Step 2 : The client reads the filename from the user (console input) and sends the file name to the server.
	char filename[MAXSIZE];	
	printf("\x1b[36m\nENTER FILENAME:\x1b[0m"); 
	scanf("%s",filename);
	send(sockfd, filename, strlen(filename)+1, 0);
	for(int i=0; i < MAXSIZE; i++) buffer[i] = '\0';

	//The recv() function shall return the length of the message in bytes written to the buffer pointed to by the buffer argument
	//The first recv() call for receiving the message code “E” or “L”,	
	int buffBytes = recv(sockfd, buffer, 1, MSG_WAITALL);
	if(buffer[0]=='E'){
		printf("\x1b[31mFile Not Found\x1b[0m\n"); 
		exit(EXIT_FAILURE);
	}
	else{	
		//The second recv() call for receiving exactly the bytes corresponding to the file size parameter.
		buffBytes = recv(sockfd, &FSIZE, 4, MSG_WAITALL);
		
		// Opening new file to write the data
		char *outputFile = filename;
		int fd = open(outputFile, O_WRONLY | O_CREAT | O_TRUNC, 0666);
		
		int fullBlocks = FSIZE/B;
		int lastBlockSize = FSIZE%B;
		int totalBlocks = fullBlocks + ( (lastBlockSize==0) ? 0 : 1);
		
		//Receiving and writing file contents in blocks of size B'
		for(int i =0; i < fullBlocks ; i++){
			buffBytes = recv(sockfd, buffer, B, MSG_WAITALL);	//Recieving file contents using MSG_WAITALL flag	
			write(fd,buffer,buffBytes);                             //Writing recieved bytes to output file
		}
		//Receiving Last Block
		buffBytes = recv(sockfd,buffer,lastBlockSize,MSG_WAITALL);
		write(fd,buffer,buffBytes);
		
		printf("\x1b[34mFILE RECEIVED SUCCESSFULLY.\x1b[0m\n");
		printf("\x1b[34mFILE CONTENTS STORED IN %s.\x1b[0m\n",outputFile); 
		printf("\x1b[32m\nThe file transfer is successful. Total number of blocks received = %d, Last block size = %d\x1b[0m\n", totalBlocks, (lastBlockSize==0&&FSIZE!=0) ? B : lastBlockSize);
		printf("\x1b[36m\nCONNECTION CLOSED BY SERVER\x1b[0m\n\n"); 
		
	}
	close(sockfd); //Close connection
	return 0; 
}
