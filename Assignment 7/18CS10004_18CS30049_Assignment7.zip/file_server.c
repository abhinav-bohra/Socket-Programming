/* --------------------------------------------------------------------------------------------------------------
   C39006: Networks Laboratory​ ​(​ GROUP ASSIGNMENT​ )
   Assignment 7 - File Transfer in Blocks
   Animesh Jain  18CS10004
   Abhinav Bohra 18CS30049
   File_Server.c
-----------------------------------------------------------------------------------------------------------------*/
#include <sys/stat.h>
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/wait.h>
#include <sys/socket.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <netdb.h>    
#include <time.h>
#include <fcntl.h>
#include <arpa/inet.h> 
#include <errno.h> 
#include <netinet/in.h> 
#include <signal.h> 

#define B 20
#define MAXSIZE 10000
#define PORT 8080 
#define SA struct sockaddr 

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
int main() 
{ 	

	int sockfd, len, FSIZE; 
	char buffer[MAXSIZE];		
	struct stat st;
 	struct sockaddr_in servaddr, cli; 
  
	// Step 1 : Socket Creation and Verification 
	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd < 0) { 
		printf("\x1b[31mSOCKET CREATION FAILED.....EXITING\x1b[0m\n"); 
		exit(EXIT_FAILURE); 
	} 
	else printf("\x1b[32mSOCKET CREATED SUCCESSFULLY\x1b[0m\n"); 
	bzero(&servaddr, sizeof(servaddr)); 

	// Filing Address Informaiton 
    	servaddr.sin_family = AF_INET;           //Domain - IPV4
   	servaddr.sin_addr.s_addr = INADDR_ANY;   //Localhost
    	servaddr.sin_port = htons(PORT);         //PORT - 8080


	// Step 2: Binding newly created socket to given IP and verification 
	if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) { 
		printf("\x1b[31mSOCKET BINDING FAILED.....EXITING\x1b[0m\n"); 
		exit(EXIT_FAILURE); 
	} 
    	else printf("\x1b[32mSOCKET SUCCESSFULLY BINDED\x1b[0m\n"); 
	
	// Now server is ready to listen and verification 
	if ((listen(sockfd, 5)) != 0) { 
		printf("\x1b[31mAHHH.....CANT LISTEN YOU :(\x1b[0m\n"); 
		exit(EXIT_FAILURE); 
	} 
	else  printf("\x1b[44mSERVER IS UP!........LISTENING\x1b[0m\n\n"); 
	len = sizeof(cli);  
		  
	while(1){

		/* The server process keeps on waiting for the next client connection. 
		   The server process needs to be closed by sending an interrupt (using CTRL + C) from the console.*/
 		
		// Step 3: Accept the data packet from client and verification 
    		int connfd = accept(sockfd, (SA*)&cli, &len); 
    		if (connfd < 0) { 
    	   		printf("\x1b[31mSERVER ACCEPT FAILED\x1b[0m\n"); 	
            		exit(EXIT_FAILURE); 
	   	} 
	    	else printf("\x1b[32mSERVER ACCEPTED CLIENT CONNECTION\x1b[0m\n"); 
	      	printf("\x1b[34mESTABLISHED CONNECTION WITH %s:%d\x1b[0m\n", inet_ntoa(cli.sin_addr), htons(cli.sin_port)); // Print the IP of the established connection
		printf("\x1b[34mWAITING FOR FILE REQUEST\x1b[0m\n");

		// Step 4: Receive the filename	
		char filename[MAXSIZE];
		int buffBytes = recv(connfd, filename, MAXSIZE, 0);
		printf("\x1b[33mSEARCHING FILE: %s\x1b[0m\n", filename); //The server looks for the file in the local directory, 					
		int fd = open(filename, O_RDONLY);

		// Step 5: Check for the file presence		
		if(fd < 0){
			//If the file is not there it sends an error message “E” (a single character message) to the client and closes the connection.
			printf("\x1b[31mFILE NOT FOUND. CLOSING CONNECTION\x1b[0m\n\n");
			strcpy(buffer,"E");
			send(connfd, buffer, sizeof(buffer) , 0);
		}

		else{
		// Step 6: If the file is present, the server first sends a message “L” followed by an integer FSIZE indicating the size of the file.

			strcpy(buffer,"L");
			send(connfd, buffer, 1 , 0);
			
			//Send File size to client 
			stat(filename, &st);
			FSIZE = st.st_size;			
			send(connfd,&FSIZE,sizeof(FSIZE),0);

			//Read and send file contents in chunks of size 'B'
			while( (buffBytes = read(fd,buffer,B)) > 0 ){
				send(connfd, buffer, buffBytes, 0);
			}

			printf("\x1b[32mFILE SENT SUCCESSFULLY. CLOSING CONNECTION\x1b[0m\n\n"); 
		}
		close(fd);	//Close the file descriptor
		close(connfd); //Close the connection
	}
	return 0;	
} 

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
