/*------------------------------------------------------------------------------
   CS39006: Assignment 5 
   Simple Communication using Datagram Socket using POSIX C
   Animesh Jain  18CS10004
   Abhinav Bohra 18CS30049
-------------------------------------------------------------------------------*/

#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 
  
#define PORT    8080 
#define MAXSIZE 1000 

int main(){

	//Step 1 : Create a UDP Socket with:-
	//Domain – AF_INET for IPv4, Type – SOCK_DGRAM for UDP, 
	//Protocol – 0 i.e. default protocol for the address family.

	int sid = socket(AF_INET,SOCK_DGRAM,0);
	if(sid < 0){
		printf("\x1b[31mSOCKET CREATION FAILED.....EXITING\x1b[0m\n");
		exit(EXIT_FAILURE);
	}
	
    	struct sockaddr_in servaddr;
	memset(&servaddr, 0, sizeof(servaddr)); 

    	// Filling server information 
    	servaddr.sin_family = AF_INET;
   	servaddr.sin_addr.s_addr = INADDR_ANY; 
    	servaddr.sin_port = htons(PORT);
       
	//Step 2 : Send Filename Message
	printf("\x1b[36mENTER FILENAME:\x1b[0m"); 
	char filename[MAXSIZE];
	scanf("%s",filename);
    	sendto(sid, (const char *)filename, strlen(filename), MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr)); 
    	
	int len;  
	char buffer[MAXSIZE];   	
	memset(buffer,0,strlen(buffer));	    		
	int n = recvfrom(sid, (char *)buffer, MAXSIZE, MSG_WAITALL, (struct sockaddr *) &servaddr, &len); 
	buffer[n] = '\0'; 
	
	if(strcmp(buffer,"FILE_NOT_FOUND") == 0 ){
		printf("\x1b[31mFile Not Found\x1b[0m\n"); 
		exit(EXIT_FAILURE);
	}

	if(strcmp(buffer,"WRONG_FILE_FORMAT") == 0 ){
		printf("\x1b[31mWrong File Format\x1b[0m\n"); 
		exit(EXIT_FAILURE);
	}

	//Step 3 : Request File Contents and write it in a file locallys

	if( strcmp(buffer,"HELLO") == 0 ){
		
		int i=1;
		char token[MAXSIZE];

		char output[MAXSIZE] = "-answer.txt";
		char temp[MAXSIZE];
		filename[strlen(filename)-4]='\0';
		strcpy(temp,filename);
		strcat(temp,output);
		strcpy(output,temp);
		FILE* fptr = fopen(output, "w");

		printf("\x1b[36mWRITING DATA IN FILE: %s\x1b[0m\n", output);
		while(1){
			
			//Send request for next word
			char message[MAXSIZE]="WORD_";
			char num[100];            
	        	sprintf(num, "%d", i);         //Coverts int i to string num
			strcat(message, num);
			sendto(sid, (const char *)message, strlen(message), MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr)); 

			//Store received word -> WORD_i
			memset(token,0,strlen(token));	//Reinitiailise the token to 0
			n = recvfrom(sid, (char *)token, MAXSIZE, MSG_WAITALL, (struct sockaddr *) &servaddr, &len); 
			token[n] = '\0'; 
			
			//End the loop on encountering END
			if(strcmp(token,"END") == 0) break;

			fprintf(fptr,"%s",token);
			fprintf(fptr,"\n");
		        i++;
		}

		 printf("\x1b[32mDATA RECEIVED.....SAVING FILE\x1b[0m\n\n");
		 fclose(fptr);
	}

	close(sid);   
	return 0;

}
