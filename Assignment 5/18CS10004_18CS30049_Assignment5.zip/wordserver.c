/*------------------------------------------------------------------------------
   CS39006: Assignment 5 
   Simple Communication using Datagram Socket using POSIX C
   Animesh Jain  18CS10004
   Abhinav Bohra 18CS30049
-------------------------------------------------------------------------------*/

#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h>   
#define PORT    8080 
#define MAXSIZE 1000

int main(){

	//Step 1 : Create a UDP Socket with:-
	//Domain – AF_INET for IPv4, Type – SOCK_DGRAM for UDP, 
	//Protocol – 0 i.e. default protocol for the address family.

	int sid = socket(AF_INET,SOCK_DGRAM,0);
	if(sid < 0){
		printf("\x1b[31mSOCKET CREATION FAILED.....EXITING\x1b[0m\n");
		exit(EXIT_FAILURE);
	}
	
    	struct sockaddr_in servaddr, cliaddr; 
	memset(&servaddr, 0, sizeof(servaddr)); 
	memset(&cliaddr, 0, sizeof(cliaddr)); 
      
    	// Filling server information 
    	servaddr.sin_family = AF_INET;
   	servaddr.sin_addr.s_addr = INADDR_ANY; 
    	servaddr.sin_port = htons(PORT);
        
	//Step 2 : Bind the socket to server address

	if ( bind(sid, (const struct sockaddr *)&servaddr, sizeof(servaddr)) < 0 ){ 
		printf("\x1b[31mBIND FAILED.....EXITING\x1b[0m\n");
		exit(EXIT_FAILURE); 
        } 

	printf("\x1b[46mSERVER IS RUNNING...... WE ARE LISTENING!\x1b[0m\n");

	//Step 3 : Keep Listening for messages from Client(s)
	socklen_t len = sizeof(cliaddr);  
 	
	 while(1) {

		char filename[MAXSIZE]; 			
		int n = recvfrom(sid, (char *)filename, MAXSIZE, MSG_WAITALL, (struct sockaddr *)&cliaddr, &len); 
		filename[n] = '\0';

		//The server looks for the file in the local directory, 
		//If the file is not there it sends back with a message FILE_NOT_FOUND.
			
		FILE* fptr = fopen(filename, "r");
		printf("\x1b[33mSEARCHING FILE: %s\x1b[0m\n", filename);
		
		if (fptr == NULL)
		{ 
			printf("\x1b[31mFILE NOT FOUND\x1b[0m\n"); 
			sendto(sid, "FILE_NOT_FOUND", strlen("FILE_NOT_FOUND"), MSG_CONFIRM, (const struct sockaddr *)&cliaddr, len); 
			exit(EXIT_FAILURE);
		}

		//If the file is present, the server reads the first line of the file
		//If first word is HELLO then sends this message to the client. 

		char token[MAXSIZE];		
		fscanf(fptr, "%s", token); //Read the first token

		//If the first token of the file is not HELLO, it prints an error
		//“Wrong File Format” and exits after sending a message WRONG_FILE_FORMAT to the client.		
		if (strcmp("HELLO", token) != 0){
			printf("\x1b[31mWRONG FILE FORMAT\x1b[0m\n"); 
			sendto(sid, "WRONG_FILE_FORMAT", strlen("WRONG_FILE_FORMAT"), MSG_CONFIRM, (const struct sockaddr *)&cliaddr, len); 
		    	exit(EXIT_FAILURE);
		
		}
		else{
			
			sendto(sid,"HELLO", strlen("HELLO"), MSG_CONFIRM, (const struct sockaddr *)&cliaddr, len); 
			    	
			int i=1; 			
			printf("\x1b[36mREADING CONTENTS OF FILE\x1b[0m\n"); 
			
			while ( fscanf(fptr, "%s", token) != EOF)
		    	{
				char message[MAXSIZE]="WORD_";
				char num[100];            
		        	sprintf(num, "%d", i);         //Coverts int i to string num
			       	strcat(message, num);

				char buffer[MAXSIZE];
				memset(buffer,0,strlen(buffer));
				n = recvfrom(sid, (char *)buffer, MAXSIZE, MSG_WAITALL, (struct sockaddr *) &servaddr, &len); 
				buffer[n] ='\0';

				if (strcmp(buffer, message) == 0){
					//Send the WORD_i if the order of request is correct
					sendto(sid, (const char *)token, strlen(token), MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr)); 
				}
				else{

					//Send error message if the order of request is incorrect
					sendto(sid, "WRONG_MESSAGE_FORMAT", strlen("WRONG_MESSAGE_FORMAT"), MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr)); 
		            	    	break;
		        	}
		        i++;
		        }

			printf("\x1b[32mDATA SENT.....CLOSING FILE\x1b[0m\n\n"); 			
			fclose(fptr);

		}
		
	}
	
	return 0;

}
